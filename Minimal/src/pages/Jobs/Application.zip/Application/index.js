import React, { useCallback, useEffect, useState } from "react";
import {
  Card,
  CardBody,
  NavLink as TabLink,
  CardHeader,
  Col,
  Container,
  Form,
  Input,
  Nav,
  NavItem,
  Row,
  Table,
  UncontrolledTooltip,
  Modal,
  ModalBody,
  Label,
  ModalHeader,
} from "reactstrap";
import Flatpickr from "react-flatpickr";
import DeleteModal from "../../../Components/Common/DeleteModal";

import BreadCrumb from "../../../Components/Common/BreadCrumb";
import { useSelector, useDispatch } from "react-redux";
import { getApplicationList } from "../../../store/actions";
import { NavLink } from "react-router-dom";
import Slack from "../../../assets/images/brands/slack.png";
import dropbox from "../../../assets/images/brands/dropbox.png";
import MultiUser from "../../../assets/images/users/multi-user.jpg";

const Application = () => {
  document.title = "Application | Velzon - React Admin & Dashboard Template";

  const dispatch = useDispatch();
  const [activeTab, setActiveTab] = useState("1");
  const [modal, setModal] = useState(false);
  const [application, setApplication] = useState([]);
  const [deleteModal, setDeleteModal] = useState(false);
  const [deleteModalMulti, setDeleteModalMulti] = useState(false);

  // const handleClose = () => setShow(false);
  // const handleShow = () => setShow(true);

  const onClickDelete = (order) => {
    setDeleteModal(true);
  };

  const { appList } = useSelector((state) => ({
    appList: state.Jobs.appList,
  }));

  useEffect(() => {
    dispatch(getApplicationList());
  }, [dispatch]);

  const toggle = useCallback(() => {
    if (modal) {
      setModal(false);
      // setOrder(null);
    } else {
      setModal(true);
      // setDate(defaultdate());
    }
  }, [modal]);

  // eslint-disable-next-line react-hooks/exhaustive-deps
  const handleApplicationClick = useCallback((arg) => {
    const application = arg;

    setApplication({
      _id: application.id,
      company: application.company,
      Designation: application.Designation,
      date: application.date,
      contact: application.contact,
      type: application.type,
      status: application.status,
    });
  });

  return (
    <React.Fragment>
      <div className="page-content">
        <DeleteModal
          show={deleteModal}
          onCloseClick={() => setDeleteModal(false)}
        />
        <DeleteModal
          show={deleteModalMulti}
          onDeleteClick={() => {
            setDeleteModalMulti(false);
          }}
          onCloseClick={() => setDeleteModalMulti(false)}
        />
        <Container fluid>
          <BreadCrumb title="Application" pageTitle="Job" />
          <Row>
            <Col>
              <Card>
                <CardHeader className="card-header  border-0">
                  <div className="d-flex align-items-center">
                    <h5 className="card-title mb-0 flex-grow-1">
                      Job Application
                    </h5>
                    <div className="flex-shrink-0">
                      <div className="d-flex gap-1 flex-wrap">
                        <button
                          type="button"
                          className="btn btn-success add-btn"
                          data-bs-toggle="modal"
                          id="create-btn"
                          data-bs-target="#showModal"
                          onClick={() => toggle()}
                        >
                          <i className="ri-add-line align-bottom me-1"></i>{" "}
                          Create Application
                        </button>
                        <button type="button" className="btn btn-info">
                          <i className="ri-file-download-line align-bottom me-1"></i>{" "}
                          Import
                        </button>
                        <button
                          className="btn btn-soft-danger"
                          id="remove-actions"
                        // onClick="deleteMultiple()"
                        >
                          <i className="ri-delete-bin-2-line"></i>
                        </button>
                      </div>
                    </div>
                  </div>
                </CardHeader>
                <CardBody className="card-body border border-dashed border-end-0 border-start-0">
                  <Form>
                    <Row className="row g-3">
                      <Col className="col-xxl-5 col-sm-6">
                        <div className="search-box">
                          <Input
                            type="text"
                            className="form-control search"
                            placeholder="Search for application ID, company, designation status or something..."
                          />
                          <i className="ri-search-line search-icon"></i>
                        </div>
                      </Col>
                      <Col className="col-xxl-2 col-sm-6">
                        <div>
                          <Flatpickr
                            className="form-control"
                            id="datepicker-publish-input"
                            placeholder="Select a date"
                            options={{
                              altInput: true,
                              altFormat: "F j, Y",
                              mode: "multiple",
                              dateFormat: "d.m.y",
                            }}
                          />
                        </div>
                      </Col>
                      <Col className="col-xxl-2 col-sm-4">
                        <div>
                          <select
                            className="form-control"
                            data-choices
                            data-choices-search-false
                            name="choices-single-default"
                            id="idStatus"
                          >
                            <option value="">Status</option>
                            <option value="all" defaultValue>
                              All
                            </option>
                            <option value="Approved">Approved</option>
                            <option value="New">New</option>
                            <option value="Pending">Pending</option>
                            <option value="Rejected">Rejected</option>
                          </select>
                        </div>
                      </Col>
                      <Col className="col-xxl-2 col-sm-4">
                        <div>
                          <select
                            className="form-control"
                            data-choices
                            data-choices-search-false
                            name="choices-single-default"
                            id="idType"
                          >
                            <option value="">Select Type</option>
                            <option value="all" defaultValue>
                              All
                            </option>
                            <option value="Full Time">Full Time</option>
                            <option value="Part Time">Part Time</option>
                          </select>
                        </div>
                      </Col>
                      <Col className="col-xxl-1 col-sm-4">
                        <div>
                          <button
                            type="button"
                            className="btn btn-primary w-100"
                          // onclick=""
                          >
                            {" "}
                            <i className="ri-equalizer-fill me-1 align-bottom"></i>
                            Filters
                          </button>
                        </div>
                      </Col>
                    </Row>
                  </Form>
                </CardBody>
                <CardBody className="card-body pt-0">
                  <div>
                    <Nav
                      className="nav nav-tabs nav-tabs-custom nav-success mb-3"
                      role="tablist"
                    >
                      <NavItem className="nav-item">
                        <TabLink
                          className="nav-link active All py-3"
                          data-bs-toggle="tab"
                          id="All"
                          to="#"
                          role="tab"
                          aria-selected="true"
                        >
                          All Application
                        </TabLink>
                      </NavItem>
                      <NavItem className="nav-item">
                        <TabLink
                          className="nav-link py-3 New"
                          data-bs-toggle="tab"
                          id="New"
                          to="#"
                          role="tab"
                          aria-selected="false"
                        >
                          New
                        </TabLink>
                      </NavItem>
                      <NavItem className="nav-item">
                        <TabLink
                          className="nav-link py-3 Pending"
                          data-bs-toggle="tab"
                          id="Pending"
                          to="#"
                          role="tab"
                          aria-selected="false"
                        >
                          Pending{" "}
                          <span className="badge bg-danger align-middle ms-1">
                            2
                          </span>
                        </TabLink>
                      </NavItem>
                      <NavItem className="nav-item">
                        <TabLink
                          className="nav-link py-3 Approved"
                          data-bs-toggle="tab"
                          id="Approved"
                          to="#"
                          role="tab"
                          aria-selected="false"
                        >
                          Approved
                        </TabLink>
                      </NavItem>
                      <NavItem className="nav-item">
                        <TabLink
                          className="nav-link py-3 Rejected"
                          data-bs-toggle="tab"
                          id="Rejected"
                          to="#"
                          role="tab"
                          aria-selected="false"
                        >
                          Rejected
                        </TabLink>
                      </NavItem>
                    </Nav>
                    <div className="table-responsive table-card mb-1">
                      <Table
                        className="table table-nowrap align-middle"
                        id="jobListTable"
                      >
                        <thead className="text-muted table-light">
                          <tr className="text-uppercase">
                            <th scope="col" style={{ width: "25px" }}>
                              <div className="form-check">
                                <Input
                                  className="form-check-input"
                                  type="checkbox"
                                  id="checkAll"
                                  defaultValue="option"
                                />
                              </div>
                            </th>
                            <th
                              className="sort"
                              data-sort="id"
                              style={{ width: "140px" }}
                            >
                              Application ID
                            </th>
                            <th className="sort" data-sort="company">
                              Company Name
                            </th>
                            <th className="sort" data-sort="designation">
                              Designation
                            </th>
                            <th className="sort" data-sort="date">
                              Apply Date
                            </th>
                            <th className="sort" data-sort="contacts">
                              Contacts
                            </th>
                            <th className="sort" data-sort="type">
                              Type
                            </th>
                            <th className="sort" data-sort="status">
                              Status
                            </th>
                            <th className="sort" data-sort="city">
                              Action
                            </th>
                          </tr>
                        </thead>
                        <tbody className="list form-check-all">
                          <tr>
                            <th scope="row">
                              <div className="form-check">
                                <Input
                                  className="form-check-input"
                                  type="checkbox"
                                  name="checkAll"
                                  value="option1"
                                />
                              </div>
                            </th>
                            <td className="id">
                              <NavLink
                                to="#"
                                className="fw-medium link-primary"
                              >
                                #VZ001
                              </NavLink>
                            </td>
                            <td className="company">
                              <div className="d-flex align-items-center">
                                <div className="flex-shrink-0">
                                  <img
                                    src={Slack}
                                    alt=""
                                    className="avatar-xxs rounded-circle image_src object-cover"
                                  />
                                </div>
                                <div className="flex-grow-1 ms-2">
                                  Syntyce Solutions
                                </div>
                              </div>
                            </td>
                            <td className="designation">Web Designer</td>
                            <td className="date">30 Sep,2022</td>
                            <td className="contacts">785-685-4616</td>
                            <td className="type">Full Time</td>
                            <td className="status">
                              <span className="badge badge-soft-danger text-uppercase">
                                Rejected
                              </span>
                            </td>
                            <td>
                              <ul className="list-inline hstack gap-2 mb-0">
                                <li className="list-inline-item">
                                  <NavLink
                                    to="apps-job-details.html"
                                    className="text-primary d-inline-block"
                                    id="viewtooltip"
                                  >
                                    <i className="ri-eye-fill fs-16"></i>
                                  </NavLink>
                                  <UncontrolledTooltip
                                    placement="top"
                                    target="viewtooltip"
                                  >
                                    View
                                  </UncontrolledTooltip>
                                </li>
                                <li className="list-inline-item edit">
                                  <NavLink
                                    to="#showModal"
                                    data-bs-toggle="modal"
                                    onClick={toggle}
                                    id="edittooltip"
                                    className="text-primary d-inline-block edit-item-btn"
                                  >
                                    <i className="ri-pencil-fill fs-16"></i>
                                  </NavLink>
                                  <UncontrolledTooltip
                                    placement="top"
                                    target="edittooltip"
                                  >
                                    Edit
                                  </UncontrolledTooltip>
                                </li>
                                <li className="list-inline-item">
                                  <NavLink
                                    onClick={() => {
                                      onClickDelete();
                                    }}
                                    className="text-danger d-inline-block remove-item-btn"
                                    data-bs-toggle="modal"
                                    to="#deleteOrder"
                                    id="removetooltip"
                                  >
                                    <i className="ri-delete-bin-5-fill fs-16"></i>
                                  </NavLink>
                                  <UncontrolledTooltip
                                    placement="top"
                                    target="removetooltip"
                                  >
                                    Remove
                                  </UncontrolledTooltip>
                                </li>
                              </ul>
                            </td>
                          </tr>
                          <tr>
                            <th scope="row">
                              <div className="form-check">
                                <Input
                                  className="form-check-input"
                                  type="checkbox"
                                  name="checkAll"
                                  value="option1"
                                />
                              </div>
                            </th>
                            <td className="id">
                              <NavLink
                                to="#"
                                className="fw-medium link-primary"
                              >
                                #VZ002
                              </NavLink>
                            </td>
                            <td className="company">
                              <div className="d-flex align-items-center">
                                <div className="flex-shrink-0">
                                  <img
                                    src={dropbox}
                                    alt=""
                                    className="avatar-xxs rounded-circle image_src object-cover"
                                  />
                                </div>
                                <div className="flex-grow-1 ms-2">Mrtin's</div>
                              </div>
                            </td>
                            <td className="designation">Business Associate</td>
                            <td className="date">24 Oct,2022</td>
                            <td className="contacts">752-647-4616</td>
                            <td className="type">Part Time</td>
                            <td className="status">
                              <span className="badge badge-soft-success text-uppercase">
                                New
                              </span>
                            </td>
                            <td>
                              <ul className="list-inline hstack gap-2 mb-0">
                                <li className="list-inline-item">
                                  <NavLink
                                    to="apps-job-details.html"
                                    className="text-primary d-inline-block"
                                    id="viewtooltip"
                                  >
                                    <i className="ri-eye-fill fs-16"></i>
                                  </NavLink>
                                  <UncontrolledTooltip
                                    placement="top"
                                    target="viewtooltip"
                                  >
                                    View
                                  </UncontrolledTooltip>
                                </li>
                                <li className="list-inline-item edit">
                                  <NavLink
                                    to="#showModal"
                                    data-bs-toggle="modal"
                                    onClick={toggle}
                                    id="edittooltip"
                                    className="text-primary d-inline-block edit-item-btn"
                                  >
                                    <i className="ri-pencil-fill fs-16"></i>
                                  </NavLink>
                                  <UncontrolledTooltip
                                    placement="top"
                                    target="edittooltip"
                                  >
                                    Edit
                                  </UncontrolledTooltip>
                                </li>
                                <li className="list-inline-item">
                                  <NavLink
                                    onClick={() => {
                                      onClickDelete();
                                    }}
                                    className="text-danger d-inline-block remove-item-btn"
                                    data-bs-toggle="modal"
                                    to="#deleteOrder"
                                    id="removetooltip"
                                  >
                                    <i className="ri-delete-bin-5-fill fs-16"></i>
                                  </NavLink>
                                  <UncontrolledTooltip
                                    placement="top"
                                    target="removetooltip"
                                  >
                                    Remove
                                  </UncontrolledTooltip>
                                </li>
                              </ul>
                            </td>
                          </tr>
                        </tbody>
                      </Table>
                    </div>
                    <div className="d-flex justify-content-end">
                      <div className="pagination-wrap hstack gap-2">
                        <NavLink
                          className="page-item pagination-prev disabled"
                          to="#"
                        >
                          Previous
                        </NavLink>
                        <ul className="pagination listjs-pagination mb-0">1</ul>
                        <NavLink className="page-item pagination-next" to="#">
                          Next
                        </NavLink>
                      </div>
                    </div>
                  </div>
                  <div
                    className="modal fade"
                    id="showModal"
                    tabIndex="-1"
                    aria-labelledby="exampleModalLabel"
                    aria-hidden="true"
                  >
                    <div className="modal-dialog modal-dialog-centered">
                      <Modal
                        id="showModal"
                        isOpen={modal}
                        toggle={toggle}
                        centered={true}
                      >
                        <ModalHeader className="modal-header bg-light p-3" toggle={toggle}>
                          {"Add Application"}
                        </ModalHeader>
                        <Form action="#" autoComplete="off">
                          <ModalBody className="modal-body">
                            <Input type="hidden" id="id-field" />

                            <div className="mb-3 d-none" id="modal-id">
                              <Label
                                htmlFor="applicationId"
                                className="form-label"
                              >
                                ID
                              </Label>
                              <Input
                                type="text"
                                id="applicationId"
                                className="form-control"
                                placeholder="ID"
                                readOnly
                              />
                            </div>

                            <div className="text-center">
                              <div className="position-relative d-inline-block">
                                <div className="position-absolute  bottom-0 end-0">
                                  <Label
                                    htmlFor="companylogo-image-input"
                                    className="mb-0"
                                    data-bs-toggle="tooltip"
                                    data-bs-placement="right"
                                    title="Select Image"
                                  >
                                    <div className="avatar-xs cursor-pointer">
                                      <div className="avatar-title bg-light border rounded-circle text-muted">
                                        <i className="ri-image-fill"></i>
                                      </div>
                                    </div>
                                  </Label>
                                  <Input
                                    className="form-control d-none"
                                    id="companylogo-image-input"
                                    type="file"
                                    accept="image/png, image/gif, image/jpeg"
                                  />
                                </div>
                                <div className="avatar-lg p-1">
                                  <div className="avatar-title bg-light rounded-circle">
                                    <img
                                      src={MultiUser}
                                      id="companylogo-img"
                                      className="avatar-md h-auto rounded-circle object-cover"
                                      alt=""
                                    />
                                  </div>
                                </div>
                              </div>
                            </div>

                            <div className="mb-3">
                              <Label
                                htmlFor="company-field"
                                className="form-label"
                              >
                                Company
                              </Label>
                              <Input
                                type="text"
                                id="company-field"
                                className="form-control"
                                placeholder="Enter company name"
                                required
                              />
                            </div>

                            <div className="mb-3">
                              <Label
                                htmlFor="designation-field"
                                className="form-label"
                              >
                                Designation
                              </Label>
                              <Input
                                type="text"
                                id="designation-field"
                                className="form-control"
                                placeholder="Enter designation"
                                required
                              />
                            </div>

                            <div className="mb-3">
                              <Label
                                htmlFor="date-field"
                                className="form-label"
                              >
                                Apply Date
                              </Label>
                              <Input
                                type="date"
                                id="date-field"
                                className="form-control"
                                data-provider="flatpickr"
                                data-date-format="d M, Y"
                                required
                                placeholder="Select date"
                              />
                            </div>

                            <div className="mb-3">
                              <Label
                                htmlFor="contact-field"
                                className="form-label"
                              >
                                Contacts
                              </Label>
                              <Input
                                type="text"
                                id="contact-field"
                                className="form-control"
                                placeholder="Enter contact"
                                required
                              />
                            </div>

                            <div className="row gy-4 mb-3">
                              <div className="col-md-6">
                                <div>
                                  <Label
                                    htmlFor="status-input"
                                    className="form-label"
                                  >
                                    Status
                                  </Label>
                                  <select
                                    className="form-control"
                                    data-trigger
                                    name="status-input"
                                    id="status-input"
                                  >
                                    <option value="">Status</option>
                                    <option value="Approved">Approved</option>
                                    <option value="New">New</option>
                                    <option value="Pending">Pending</option>
                                    <option value="Rejected">Rejected</option>
                                  </select>
                                </div>
                              </div>
                              <div className="col-md-6">
                                <div>
                                  <Label
                                    htmlFor="type-input"
                                    className="form-label"
                                  >
                                    Type
                                  </Label>
                                  <select
                                    className="form-control"
                                    data-trigger
                                    name="type-input"
                                    id="type-input"
                                  >
                                    <option value="">Select Type</option>
                                    <option value="Full Time">Full Time</option>
                                    <option value="Part Time">Part Time</option>
                                  </select>
                                </div>
                              </div>
                            </div>
                          </ModalBody>
                          <div className="modal-footer">
                            <div className="hstack gap-2 justify-content-end">
                              <button
                                type="button"
                                className="btn btn-light"
                                data-bs-dismiss="modal"
                                onClick={() => {
                                  setModal(false);
                                }}
                              >
                                Close
                              </button>
                              <button
                                type="submit"
                                className="btn btn-success"
                                id="add-btn"
                              >
                                Add
                              </button>
                              {/* <button
                                type="button"
                                className="btn btn-success"
                                id="edit-btn"
                              >
                                Update
                              </button> */}
                            </div>
                          </div>
                        </Form>
                      </Modal>
                    </div>
                  </div>
                </CardBody>
              </Card>
            </Col>
          </Row>
        </Container>
      </div>
    </React.Fragment>
  );
};

export default Application;
